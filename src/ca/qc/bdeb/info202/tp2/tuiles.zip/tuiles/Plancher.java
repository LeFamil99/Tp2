package ca.qc.bdeb.info202.tp2.tuiles;

public class Plancher extends Tuile {
    public Plancher(int x, int y) {
        super(x, y, ' ', true);
    }
}
